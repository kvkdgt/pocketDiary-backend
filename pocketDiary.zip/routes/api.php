<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\UserController;
use App\Http\Controllers\ContactsController;

Route::post('/signup', [UserController::class, 'signup']);
Route::post('/login', [UserController::class, 'login']);
Route::middleware('auth:sanctum')->post('/logout', [UserController::class, 'logout']);
Route::post('/sendOTP', [UserController::class, 'sendOTP']);
Route::post('/updatePassword', [UserController::class, 'updatePassword']);

Route::middleware('auth:sanctum')->get('/contacts/get', [ContactsController::class, 'getContacts']);
Route::middleware('auth:sanctum')->get('/contacts/search/{phoneNumber}', [ContactsController::class, 'searchByPhoneNumber']);
Route::middleware('auth:sanctum')->post('/contacts/sendRequest', [ContactsController::class, 'sendRequest']);
Route::middleware('auth:sanctum')->get('/contacts/getPendingRequest', [ContactsController::class, 'getPendingRequest']);
Route::middleware('auth:sanctum')->delete('/contacts/remove/{userId}', [ContactsController::class, 'removeContact']);
Route::middleware('auth:sanctum')->put('/contacts/accept/{id}', [ContactsController::class, 'acceptContact']);



